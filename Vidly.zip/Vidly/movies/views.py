from django.shortcuts import render
from django.http import HttpResponse
from .models import Genre
# Create your views here.
def index(request):
    # read data frim DB
    genres = Genre.objects.all()

    """

    get all: Class.object.all()
    id: Class.objects.get(id=1)
    
    filter:
        Movie.objects.filter(release_year = 1994)

    """
   
    return render(request, 'views/index.html', { 'title' : 'Index Page', 'items' : genres})

def catalog(request):
    return render(request, 'views/catalog.html')

def welcome(request):
    return render(request, 'views/welcome.html', { 'title' : 'Welcome', 'rows' : 2})

def about(request):
    return HttpResponse("<h1> I'm Carlos Teran </h1>")

